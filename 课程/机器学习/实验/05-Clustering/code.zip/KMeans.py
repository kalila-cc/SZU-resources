from utils import *


class Kmeans:
    def __init__(self, k: int):
        self.k = k
        self.max_epoch = 10 * k
        self.randtimes = 2 * k
        self.dim = None
        self.kernel = None
        self.label = None

    def fit(self, X: np.ndarray):
        num_samples = X.shape[0]
        self.dim = X.shape[1]
        self.kernel = np.zeros((self.k, self.dim))
        self.label = np.zeros((num_samples,))
        lim = np.zeros((2, self.dim))
        lim[0] = np.min(X, axis=0)
        lim[1] = np.max(X, axis=0)
        kernel_list = []
        for times in range(self.randtimes):
            for dim in range(self.dim):
                self.kernel[:, dim] = lim[0, dim] + (lim[1, dim] - lim[0, dim]) * np.random.rand(self.k)
            epoch = 0
            while True:
                old_kernel = self.kernel.copy()
                for i in range(num_samples):
                    self.label[i] = np.argmin(la.norm(self.kernel - X[i], axis=1))
                for i in range(self.k):
                    colabel = self.label == i
                    self.kernel[i] = np.random.rand(self.dim) if not colabel.any() else np.mean(X[colabel], axis=0)
                delta = la.norm(old_kernel - self.kernel)
                epoch += 1
                if delta < 1e-2 or epoch >= self.max_epoch:
                    break
            kernel_list.append((times, epoch, self.kernel.copy()))
        opt_kernel_info = min(kernel_list, key=lambda x: x[1])
        self.kernel = opt_kernel_info[2].copy()
        for i in range(num_samples):
            self.label[i] = np.argsort(la.norm(self.kernel - X[i], axis=1))[0]

    def test(self, X: np.ndarray, y: np.ndarray):
        num_err = 0
        num_samples = X.shape[0]
        label = np.zeros((num_samples,))
        for i in range(num_samples):
            label[i] = np.argmin(la.norm(self.kernel - X[i], axis=1))
        for i in range(self.k):
            colabel = self.label == i
            if colabel.any():
                coy = y[colabel]
                num_err += np.count_nonzero(coy - np.argmax(np.bincount(coy)))
        return 1.0 - num_err / num_samples

    def show(self, X: np.ndarray, dim: int):
        if dim == 2:
            plt.scatter(X[:, 0], X[:, 1], marker='+', c=self.label, cmap=plt.get_cmap('rainbow'))
            plt.scatter(self.kernel[:, 0], self.kernel[:, 1], marker='v', c=np.arange(self.k), cmap=plt.get_cmap('rainbow'))
            plt.show()
        elif dim == 3:
            ax = Axes3D(plt.figure())
            ax.scatter(X[:, 0], X[:, 1], X[:, 2], marker='+', c=self.label, cmap=plt.get_cmap('rainbow'))
            ax.scatter(self.kernel[:, 0], self.kernel[:, 1], self.kernel[:, 2], marker='v', c=np.arange(self.k), cmap=plt.get_cmap('rainbow'))
            plt.show()


def main():
    # 生成 2D 随机数据集
    # n_samples = 3 * 10
    # centers = 3
    # n_features = 3
    # X, y = datasets.make_blobs(n_samples=n_samples, n_features=n_features, centers=centers, center_box=(-5, 5))
    # model = Kmeans(centers)
    # model.fit(X)
    # model.show(X, dim=n_features)

    # 生成 3D 随机数据集
    # n_samples = 3 * 10
    # centers = 3
    # n_features = 3
    # X, y = datasets.make_blobs(n_samples=n_samples, n_features=n_features, centers=centers, center_box=(-5, 5))
    # model = Kmeans(centers)
    # model.fit(X)
    # model.show(X, dim=n_features)

    # 旋转人脸测试
    # path = './database/ORL4646.mat'
    # data = np.array(loadMatFile(path))
    # shape = data.shape
    # data = data.reshape((shape[0] * shape[1], shape[2])).T
    # data = data[list(range(30))]
    # tr = PCA(data, k=3)
    # X = data @ tr
    # y = genLabel(X, group_num=10)
    # model = Kmeans(k=4)
    # model.fit(X)
    # model.show(X, dim=3)
    # accuracy = model.test(X, y)
    # print('accuracy = {:.2f}'.format(accuracy))

    # 旋转物体测试
    # path = './database/COIL20.mat'
    # data = np.array(loadMatFile(path))
    # data = data[list(range(72 * 3))]
    # tr = PCA(data, k=8)
    # X = data @ tr
    # y = genLabel(X, group_num=72)
    # model = Kmeans(k=4)
    # model.fit(X)
    # model.show(X, dim=3)
    # accuracy = model.test(X, y)
    # print('accuracy = {:.2f}'.format(accuracy))

    pass


if __name__ == '__main__':
    main()
