import numpy as np
import numpy.linalg as la
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from utils import changeIntoOneHotCode, PCA, centralize, getLabel
import scipy.io as scio


class FullyConnectedNeuralNetwork:
    def __init__(self, layer: tuple, max_epoch: int, eta: float = 0.1):
        self.__layer = layer
        self.__num_layers = len(layer)
        self.__max_epoch = max_epoch
        self.__eta = eta
        self.__W = []
        for i in range(len(layer) - 1):
            self.__W.append(np.random.rand(layer[i + 1], layer[i]))
        self.__neuron = []
        for i in range(len(layer)):
            self.__neuron.append(np.zeros((layer[i], 1)))

    def fit(self, X: np.ndarray, Y: np.ndarray):
        num_samples = X.shape[0]
        loss_record = [self.__calcLoss(X, Y)]
        for epoch in range(self.__max_epoch):
            for i in range(num_samples):
                x, y = X[[i]].T, Y[[i]].T
                neuron = [x]
                for layer in range(self.__num_layers - 1):
                    neuron.append(self.__sigmoid(self.__W[layer] @ neuron[layer]))
                pLpn = [neuron[self.__num_layers - 1] - y]
                for layer in range(self.__num_layers - 1, 1, -1):
                    pLpn.append(self.__W[layer - 1].T @ (pLpn[-1] * neuron[layer] * (1 - neuron[layer])))
                pLpn.reverse()
                pLpW = []
                for layer in range(self.__num_layers - 1):
                    pLpW.append((pLpn[layer] * neuron[layer + 1] * (1 - neuron[layer + 1])) @ neuron[layer].T)
                    self.__W[layer] -= self.__eta * pLpW[layer]
            loss_record.append(self.__calcLoss(X, Y))
            print('\rprogress rate: {:5.2f} %'.format(100 * (epoch + 1) / self.__max_epoch), end='')
        print()
        # 测试误差是否正在下降
        plt.plot(range(len(loss_record)), loss_record)
        plt.show()

    def pred(self, x: np.ndarray):
        neuron = [x]
        for layer in range(self.__num_layers - 1):
            neuron.append(self.__sigmoid(self.__W[layer] @ neuron[layer]))
        return neuron[-1]

    def __calcLoss(self, X: np.ndarray, Y: np.ndarray) -> float:
        loss = 0.0
        num_samples = X.shape[0]
        for i in range(num_samples):
            x, y = X[[i]].T, Y[[i]].T
            loss += 0.5 * np.squeeze(la.norm(self.pred(x) - y))
        return loss

    @staticmethod
    def __sigmoid(x: np.ndarray) -> np.ndarray:
        return 1.0 / (1.0 + np.exp(-x))


def main_for_mnist():
    # 获得数据集
    mnist = scio.loadmat('./database/mnist.mat')
    X, y = mnist['data'].astype(np.float).T, mnist['label'].T
    # 随计选择样本
    num_samples = 2000
    index = np.random.choice(np.arange(X.shape[0]), size=num_samples, replace=False)
    X, y = X[index], y[index]
    # 中心化 + PCA 降维 + one-hot 编码
    dim = 20
    X = centralize(X)[0]
    X = X @ PCA(X, k=dim)
    Y = changeIntoOneHotCode(y)
    # 分割数据集
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.1)
    # 创建全连接神经网络实例 + 模型拟合 + 模型预测
    fcnn = FullyConnectedNeuralNetwork(layer=(dim, 35, 25, 10), max_epoch=2000, eta=0.1)
    fcnn.fit(X, Y)
    Y_pred = fcnn.pred(X_test.T).T
    # 计算预测准确率
    correct_rate = 0
    for i in range(Y_pred.shape[0]):
        if np.argmax(Y_pred[i]) == np.argmax(Y_test[i]):
            correct_rate += 1
    correct_rate /= Y_pred.shape[0]
    # 输出结果
    print('correct rate is {:.2f} %'.format(correct_rate * 100))
    pass


def main_for_orl():
    # 获得数据集
    orl = scio.loadmat('./database/ORL4646.mat')
    X = orl['ORL4646']
    X = X.reshape((X.shape[0] * X.shape[1], X.shape[2])).T
    X = centralize(X)[0]
    # PCA 降维 + one-hot 编码
    dim = 20
    X = X @ PCA(X, k=dim)
    Y = changeIntoOneHotCode(getLabel(X, group_num=10))
    # 分割数据集
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.1)
    # 创建全连接神经网络实例 + 模型拟合 + 模型预测
    fcnn = FullyConnectedNeuralNetwork(layer=(dim, 45, 35, 40), max_epoch=1000, eta=0.5)
    fcnn.fit(X, Y)
    Y_pred = fcnn.pred(X_test.T).T
    # 计算预测准确率
    correct_rate = 0
    for i in range(Y_pred.shape[0]):
        if np.argmax(Y_pred[i]) == np.argmax(Y_test[i]):
            correct_rate += 1
    correct_rate /= Y_pred.shape[0]
    # 输出结果
    print('correct rate is {:.2f} %'.format(correct_rate * 100))
    pass


if __name__ == '__main__':
    main_for_mnist()
    # main_for_orl()
