import numpy as np
import numpy.linalg as la
import scipy.io as scio


def loadMatFile(filepath: str):
    k = ''
    mat_data = scio.loadmat(filepath)
    for key in mat_data.keys():
        if not key.startswith('__'):
            k = key
            break
    return mat_data[k]


def addBius(original_data: np.ndarray):
    return np.hstack((original_data, uplift(np.ones(original_data.shape[0]))))


def centralize(original_data: np.ndarray, stripLabel: bool = False) -> (np.ndarray, np.ndarray):
    mu = np.mean(original_data, axis=0)
    mu[-1] = 0 if stripLabel else mu[-1]
    original_data -= mu
    return original_data, mu


def PCA(original_data: np.ndarray, k: int, stripLabel: bool = False) -> np.ndarray:
    return la.svd(original_data[:, :-1].T)[0][:, :k] if stripLabel else la.svd(original_data.T)[0][:, :k]


def crossValidation(dataset: np.ndarray, fold: int, part: int = -1, discrete: bool = False) -> (np.ndarray, np.ndarray):
    if discrete:
        size, indexes = dataset.shape[0], []
        for i in range(part):
            indexes.extend(list(range(i, size + i, part)))
        dataset = dataset[indexes]
    part = dataset.shape[0] // fold
    for i in range(fold):
        train_set = np.vstack((dataset[: i * part], dataset[(i + 1) * part:]))
        test_set = dataset[i * part: (i + 1) * part]
        yield train_set, test_set


def predict(transfrom: np.ndarray, test_X: np.ndarray, test_Y: np.ndarray, discrete: bool = False, func=None):
    if discrete:
        cnt = 0
        if func is None:
            pred_Y, real_Y = test_X @ transfrom, test_Y
        else:
            pred_Y, real_Y = func(test_X @ transfrom), test_Y
        for pred_Yi, real_Yi in zip(pred_Y, real_Y):
            cnt += 1 if np.argmax(pred_Yi) == np.argmax(real_Yi) else 0
        return cnt / len(pred_Y)
    else:
        delta = test_X @ transfrom - test_Y
        return np.sum(delta * delta)


def one_hot_code(nSample: int, feat: int) -> np.ndarray:
    Y = np.zeros((nSample, feat))
    for i in range(feat):
        Y[i * 10: (i + 1) * 10, i] = 1
    return Y


if __name__ == '__main__':
    pass
