from utils import *


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def LinearRegression(X: np.ndarray, Y: np.ndarray):
    return la.inv(X.T @ X) @ X.T @ Y


def LogisticsRegression(X: np.ndarray, Y: np.ndarray):
    W, eta = np.random.rand(X.shape[1], Y.shape[1]), 0.01
    for i in range(250):
        grad = X.T @ (sigmoid(X @ W) - Y)
        W -= eta * grad
    return W


def RidgeRegression(X: np.ndarray, Y: np.ndarray, alpha: float = 0):
    return la.inv((X.T @ X + np.diag([alpha] * X.shape[1]))) @ X.T @ Y


def LassoRegression(X: np.ndarray, Y: np.ndarray, alpha: float):
    W = np.random.rand(X.shape[1], Y.shape[1])
    threshold = 0.01
    r = predict(W, X, Y)
    while True:
        for col in range(Y.shape[1]):
            for k in range(X.shape[1]):
                f_k = X[:, k: k + 1]
                z_k = f_k.T @ f_k
                partial = -2 * f_k.T @ (Y[:, col: col + 1] - X @ W[:, col: col + 1])
                p_k = z_k * W[k, col] - 0.5 * partial
                if p_k < -0.5 * alpha:
                    W[k, col] = (p_k + 0.5 * alpha) / z_k
                elif p_k > 0.5 * alpha:
                    W[k, col] = (p_k - 0.5 * alpha) / z_k
                else:
                    W[k, col] = 0
        r_primary = predict(W, X, Y)
        delta = np.abs(r - r_primary)
        r = r_primary
        if delta < threshold:
            break
    return W


def test_LinearRegression(face_data: np.ndarray):
    # 数据处理
    feat = 40
    tr_pca = PCA(face_data, k=61)
    X = addBius(face_data @ tr_pca)
    # one-hot 编码
    Y = one_hot_code(nSample=X.shape[0], feat=feat)
    XY = np.hstack((X, Y))
    # 十折交叉验证
    rec_rate_list = []
    for train_XY, test_XY in crossValidation(XY, fold=10, part=10, discrete=True):
        train_X, train_Y = train_XY[:, :-feat], train_XY[:, -feat:]
        test_X, test_Y = test_XY[:, :-feat], test_XY[:, -feat:]
        W = LinearRegression(train_X, train_Y)
        rec_rate_list.append(predict(W, test_X, test_Y, discrete=True))
    avg_rec_rate = np.mean(rec_rate_list)
    print('Linear Regression : average recognition rate is {:.2f} %'.format(100 * avg_rec_rate))


def test_LogisticsRegression(face_data: np.ndarray):
    # 数据处理
    feat = 40
    tr_pca = la.svd(face_data.T)[0][:, :50]
    X = addBius(face_data @ tr_pca)
    # one-hot 编码
    Y = one_hot_code(nSample=X.shape[0], feat=feat)
    XY = np.hstack((X, Y))
    # 十折交叉验证
    rec_rate_list = []
    for train_XY, test_XY in crossValidation(XY, fold=10, part=10, discrete=True):
        train_X, train_Y = train_XY[:, :-feat], train_XY[:, -feat:]
        test_X, test_Y = test_XY[:, :-feat], test_XY[:, -feat:]
        W = LogisticsRegression(train_X, train_Y)
        rec_rate_list.append(predict(W, test_X, test_Y, discrete=True, func=sigmoid))
    avg_rec_rate = np.mean(rec_rate_list)
    print('Logistics Regression : average recognition rate is {:.2f} %'.format(100 * avg_rec_rate))


def test_RidgeRegression(face_data: np.ndarray):
    # 数据处理
    feat = 40
    tr_pca = PCA(face_data, k=400)
    X = addBius(face_data @ tr_pca)
    # one-hot 编码
    Y = one_hot_code(nSample=X.shape[0], feat=feat)
    XY = np.hstack((X, Y))
    # 十折交叉验证
    rec_rate_list, alpha = [], 1e-8
    for train_XY, test_XY in crossValidation(XY, fold=10, part=10, discrete=True):
        train_X, train_Y = train_XY[:, :-feat], train_XY[:, -feat:]
        test_X, test_Y = test_XY[:, :-feat], test_XY[:, -feat:]
        W = RidgeRegression(train_X, train_Y, alpha)
        rec_rate_list.append(predict(W, test_X, test_Y, discrete=True))
    avg_rec_rate = np.mean(rec_rate_list)
    print('Ridge Regression : average recognition rate is {:.2f} %'.format(100 * np.mean(avg_rec_rate)))


def test_LassoRegression(face_data: np.ndarray):
    # 数据处理
    feat = 40
    tr_pca = PCA(face_data, k=61)
    X = addBius(face_data @ tr_pca)
    # one-hot 编码
    Y = one_hot_code(nSample=X.shape[0], feat=feat)
    XY = np.hstack((X, Y))
    # 十折交叉验证
    rec_rate_list, alpha = [], 1e-2
    for train_XY, test_XY in crossValidation(XY, fold=10, part=10, discrete=True):
        train_X, train_Y = train_XY[:, :-feat], train_XY[:, -feat:]
        test_X, test_Y = test_XY[:, :-feat], test_XY[:, -feat:]
        W = LassoRegression(train_X, train_Y, alpha)
        rec_rate_list.append(predict(W, test_X, test_Y, discrete=True))
    avg_rec_rate = np.mean(rec_rate_list)
    print('Lasso Regression : average recognition rate is {:.2f} %'.format(100 * avg_rec_rate))


def main():
    # 获取数据
    path = './database/ORL4646.mat'
    face_data = np.array(loadMatFile(path))
    shape = face_data.shape
    face_data = face_data.reshape((shape[0] * shape[1], shape[2])).T
    face_data, mean_face = centralize(face_data)
    # 测试数据
    test_LinearRegression(face_data)
    test_LogisticsRegression(face_data + mean_face)
    test_RidgeRegression(face_data)
    test_LassoRegression(face_data)


if __name__ == '__main__':
    main()
