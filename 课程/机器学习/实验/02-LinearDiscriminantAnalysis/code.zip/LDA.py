from utils import *


def displayFacelib(original_data: np.ndarray, h: int, w: int, n: int, size: tuple, stripLabel: bool = False):
    if stripLabel:
        for i in range(n):
            plt.subplot(h, w, i + 1)
            plt.imshow(original_data[i][:-1].reshape(size), cmap='Greys_r')
            plt.axis('off')
        pass
    else:
        for i in range(n):
            plt.subplot(h, w, i + 1)
            plt.imshow(original_data[i].reshape(size), cmap='Greys_r')
            plt.axis('off')
    plt.tight_layout()
    plt.show()


# genarate data
def genarate_data():
    # ORL
    path = './database/ORL4646.mat'
    face_data = np.array(loadMatFile(path))
    shape = face_data.shape
    face_data = face_data.reshape((shape[0] * shape[1], shape[2])).T
    fold = selectFactor(face_data)
    part = 10
    # Yale
    # path = './database/Yale5040165.mat'
    # face_data = np.array(loadMatFile(path)).astype(np.float)
    # shape = face_data.shape
    # face_data = face_data.reshape((shape[0] * shape[1], shape[2])).T
    # fold = selectFactor(face_data)
    # part = 11
    # AR
    # path = './database/AR120p20s50by40'
    # face_data = np.array(loadMatFile(path)).astype(np.float)
    # shape = face_data.shape
    # face_data = face_data.reshape((shape[0] * shape[1], shape[2])).T[:400]
    # fold = selectFactor(face_data)
    # part = 20
    return face_data, fold, part


# Sw^-1 @ Sb
def LDA_M1(original_data: np.ndarray, k: int):
    shape = original_data.shape
    cls_info, cls_index, cls_num = getLabelInfo(original_data)
    mu = np.mean(original_data, axis=0)[:-1]
    Sw = np.zeros((shape[1] - 1, shape[1] - 1))
    Sb = np.zeros((shape[1] - 1, shape[1] - 1))
    for i in range(cls_num):
        X_i = original_data[cls_index[i]: cls_index[i + 1]]
        label = X_i[0, -1]
        X_i = X_i[:, :-1]
        mu_i = np.mean(X_i, axis=0)
        X_i = X_i - mu_i
        Sw += X_i.T @ X_i
        mu_i = uplift(mu_i - mu)
        Sb += cls_info[label] * mu_i.T @ mu_i
    A = la.pinv(Sw) @ Sb
    eigVal, eigVec = la.eig(A)
    eigVal, eigVec = eigVal.real, eigVec.real
    eigVec = eigVec[:, np.argsort(eigVal)[-k:][::-1]]
    return eigVec


# Sw^-1 @ Sb  --  main
def main_M1():
    # 数据处理
    face_data, fold, part = genarate_data()
    face_data, mean_face = centralize(face_data)
    face_data = addLabel(face_data, part)

    # 正式识别
    correct_rate = []
    for train_data, test_data in crossValidation(face_data, fold, discrete=True, part=part):
        train_data = np.array(sorted(train_data, key=lambda x: x[-1]))
        shape = train_data.shape
        cls_info, cls_index, cls_num = getLabelInfo(train_data)
        if shape[1] - 1 > shape[0] - cls_num:
            tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
            train_data = dotWithLabel(train_data, tr_pca)
            test_data = dotWithLabel(test_data, tr_pca)
        tr_lda = LDA_M1(train_data, cls_num - 1)
        lda_train_data = dotWithLabel(train_data, tr_lda)
        lda_test_data = dotWithLabel(test_data, tr_lda)
        test_labels = uplift(lda_test_data[:, -1])
        match_labels = KNN(lda_train_data, lda_test_data, k=1)
        correct_rate.append(sum([1 if tl == ml else 0 for tl, ml in zip(test_labels, match_labels)]) / len(test_labels))
        print('correct rate is {:.2f} %'.format(correct_rate[-1] * 100))
    print('average correct rate is {:.2f} %'.format(sum(correct_rate) / len(correct_rate) * 100))

    # 降维测试
    # shape = face_data.shape
    # cls_info, cls_index, cls_num = getLabelInfo(face_data)
    # if shape[1] - 1 > shape[0] - cls_num:
    #     tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
    #     face_data = dotWithLabel(face_data, tr_pca)
    # tr_lda = LDA_M1(face_data, cls_num - 1)
    # lda_data = dotWithLabel(face_data, tr_lda)
    # draw(dim=3)
    # for i in range(10):
    #     visualize(lda_data[i * 10: (i + 1) * 10], dim=3)
    # plt.show()
    pass


# (Sb - Sw)^-1
def LDA_M2(original_data: np.ndarray, k: int):
    shape = original_data.shape
    cls_info, cls_index, cls_num = getLabelInfo(original_data)
    mu = np.mean(original_data, axis=0)[:-1]
    Sw = np.zeros((shape[1] - 1, shape[1] - 1))
    Sb = np.zeros((shape[1] - 1, shape[1] - 1))
    for i in range(cls_num):
        X_i = original_data[cls_index[i]: cls_index[i + 1]]
        label = X_i[0, -1]
        X_i = X_i[:, :-1]
        mu_i = np.mean(X_i, axis=0)
        X_i = X_i - mu_i
        Sw += X_i.T @ X_i
        mu_i = uplift(mu_i - mu)
        Sb += cls_info[label] * mu_i.T @ mu_i
    A = la.pinv(Sb - Sw)
    eigVal, eigVec = la.eig(A)
    eigVal, eigVec = eigVal.real, eigVec.real
    eigVec = eigVec[:, np.argsort(eigVal)[-k:][::-1]]
    return eigVec


# (Sb - Sw)^-1  --  main
def main_M2():
    # 数据处理
    face_data, fold, part = genarate_data()
    face_data, mean_face = centralize(face_data)
    face_data = addLabel(face_data, part)

    # 正式识别
    correct_rate = []
    for train_data, test_data in crossValidation(face_data, fold, discrete=True, part=part):
        train_data = np.array(sorted(train_data, key=lambda x: x[-1]))
        shape = train_data.shape
        cls_info, cls_index, cls_num = getLabelInfo(train_data)
        if shape[1] - 1 > shape[0] - cls_num:
            tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
            train_data = dotWithLabel(train_data, tr_pca)
            test_data = dotWithLabel(test_data, tr_pca)
        tr_lda = LDA_M2(train_data, cls_num - 1)
        lda_train_data = dotWithLabel(train_data, tr_lda)
        lda_test_data = dotWithLabel(test_data, tr_lda)
        test_labels = uplift(lda_test_data[:, -1])
        match_labels = KNN(lda_train_data, lda_test_data, k=1)
        correct_rate.append(sum([1 if tl == ml else 0 for tl, ml in zip(test_labels, match_labels)]) / len(test_labels))
        print('correct rate is {:.2f} %'.format(correct_rate[-1] * 100))
    print('average correct rate is {:.2f} %'.format(sum(correct_rate) / len(correct_rate) * 100))

    # 降维测试
    # shape = face_data.shape
    # cls_info, cls_index, cls_num = getLabelInfo(face_data)
    # if shape[1] - 1 > shape[0] - cls_num:
    #     tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
    #     face_data = dotWithLabel(face_data, tr_pca)
    # tr_lda = LDA_M2(face_data, cls_num - 1)
    # lda_data = dotWithLabel(face_data, tr_lda)
    # draw(dim=3)
    # for i in range(10):
    #     visualize(lda_data[i * 10: (i + 1) * 10], dim=3)
    # plt.show()
    pass


# St^-1 @ Sb
def LDA_M3(original_data: np.ndarray, k: int):
    shape = original_data.shape
    cls_info, cls_index, cls_num = getLabelInfo(original_data)
    mu = np.mean(original_data, axis=0)[:-1]
    Sw = np.zeros((shape[1] - 1, shape[1] - 1))
    Sb = np.zeros((shape[1] - 1, shape[1] - 1))
    for i in range(cls_num):
        X_i = original_data[cls_index[i]: cls_index[i + 1]]
        label = X_i[0, -1]
        X_i = X_i[:, :-1]
        mu_i = np.mean(X_i, axis=0)
        X_i = X_i - mu_i
        Sw += X_i.T @ X_i
        mu_i = uplift(mu_i - mu)
        Sb += cls_info[label] * mu_i.T @ mu_i
    A = la.pinv(Sw + Sb) @ Sb
    eigVal, eigVec = la.eig(A)
    eigVal, eigVec = eigVal.real, eigVec.real
    eigVec = eigVec[:, np.argsort(eigVal)[-k:][::-1]]
    return eigVec


# St^-1 @ Sb  --  main
def main_M3():
    # 数据处理
    face_data, fold, part = genarate_data()
    face_data, mean_face = centralize(face_data)
    face_data = addLabel(face_data, part)

    # 正式识别
    correct_rate = []
    for train_data, test_data in crossValidation(face_data, fold, discrete=True, part=part):
        train_data = np.array(sorted(train_data, key=lambda x: x[-1]))
        shape = train_data.shape
        cls_info, cls_index, cls_num = getLabelInfo(train_data)
        if shape[1] - 1 > shape[0] - cls_num:
            tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
            train_data = dotWithLabel(train_data, tr_pca)
            test_data = dotWithLabel(test_data, tr_pca)
        tr_lda = LDA_M3(train_data, cls_num - 1)
        lda_train_data = dotWithLabel(train_data, tr_lda)
        lda_test_data = dotWithLabel(test_data, tr_lda)
        test_labels = uplift(lda_test_data[:, -1])
        match_labels = KNN(lda_train_data, lda_test_data, k=1)
        correct_rate.append(sum([1 if tl == ml else 0 for tl, ml in zip(test_labels, match_labels)]) / len(test_labels))
        print('correct rate is {:.2f} %'.format(correct_rate[-1] * 100))
    print('average correct rate is {:.2f} %'.format(sum(correct_rate) / len(correct_rate) * 100))

    # 降维测试
    # shape = face_data.shape
    # cls_info, cls_index, cls_num = getLabelInfo(face_data)
    # if shape[1] - 1 > shape[0] - cls_num:
    #     tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
    #     face_data = dotWithLabel(face_data, tr_pca)
    # tr_lda = LDA_M3(face_data, cls_num - 1)
    # lda_data = dotWithLabel(face_data, tr_lda)
    # draw(dim=3)
    # for i in range(10):
    #     visualize(lda_data[i * 10: (i + 1) * 10], dim=3)
    # plt.show()
    pass


# Sw^-1 @ St
def LDA_M4(original_data: np.ndarray, k: int):
    shape = original_data.shape
    cls_info, cls_index, cls_num = getLabelInfo(original_data)
    mu = np.mean(original_data, axis=0)[:-1]
    Sw = np.zeros((shape[1] - 1, shape[1] - 1))
    Sb = np.zeros((shape[1] - 1, shape[1] - 1))
    for i in range(cls_num):
        X_i = original_data[cls_index[i]: cls_index[i + 1]]
        label = X_i[0, -1]
        X_i = X_i[:, :-1]
        mu_i = np.mean(X_i, axis=0)
        X_i = X_i - mu_i
        Sw += X_i.T @ X_i
        mu_i = uplift(mu_i - mu)
        Sb += cls_info[label] * mu_i.T @ mu_i
    A = la.pinv(Sw) @ (Sw + Sb)
    eigVal, eigVec = la.eig(A)
    eigVal, eigVec = eigVal.real, eigVec.real
    eigVec = eigVec[:, np.argsort(eigVal)[-k:][::-1]]
    return eigVec


# Sw^-1 @ St  --  main
def main_M4():
    # 数据处理
    face_data, fold, part = genarate_data()
    face_data, mean_face = centralize(face_data)
    face_data = addLabel(face_data, part)

    # 正式识别
    correct_rate = []
    for train_data, test_data in crossValidation(face_data, fold, discrete=True, part=part):
        train_data = np.array(sorted(train_data, key=lambda x: x[-1]))
        shape = train_data.shape
        cls_info, cls_index, cls_num = getLabelInfo(train_data)
        if shape[1] - 1 > shape[0] - cls_num:
            tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
            train_data = dotWithLabel(train_data, tr_pca)
            test_data = dotWithLabel(test_data, tr_pca)
        tr_lda = LDA_M4(train_data, cls_num - 1)
        lda_train_data = dotWithLabel(train_data, tr_lda)
        lda_test_data = dotWithLabel(test_data, tr_lda)
        test_labels = uplift(lda_test_data[:, -1])
        match_labels = KNN(lda_train_data, lda_test_data, k=1)
        correct_rate.append(sum([1 if tl == ml else 0 for tl, ml in zip(test_labels, match_labels)]) / len(test_labels))
        print('correct rate is {:.2f} %'.format(correct_rate[-1] * 100))
    print('average correct rate is {:.2f} %'.format(sum(correct_rate) / len(correct_rate) * 100))

    # 降维测试
    # shape = face_data.shape
    # cls_info, cls_index, cls_num = getLabelInfo(face_data)
    # if shape[1] - 1 > shape[0] - cls_num:
    #     tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
    #     face_data = dotWithLabel(face_data, tr_pca)
    # tr_lda = LDA_M4(face_data, cls_num - 1)
    # lda_data = dotWithLabel(face_data, tr_lda)
    # draw(dim=3)
    # for i in range(10):
    #     visualize(lda_data[i * 10: (i + 1) * 10], dim=3)
    # plt.show()
    pass


# (Sw + rI)^-1 @ Sb
def LDA_M5(original_data: np.ndarray, k: int):
    shape = original_data.shape
    cls_info, cls_index, cls_num = getLabelInfo(original_data)
    mu = np.mean(original_data, axis=0)[:-1]
    Sw = np.zeros((shape[1] - 1, shape[1] - 1))
    Sb = np.zeros((shape[1] - 1, shape[1] - 1))
    for i in range(cls_num):
        X_i = original_data[cls_index[i]: cls_index[i + 1]]
        label = X_i[0, -1]
        X_i = X_i[:, :-1]
        mu_i = np.mean(X_i, axis=0)
        X_i = X_i - mu_i
        Sw += X_i.T @ X_i
        mu_i = uplift(mu_i - mu)
        Sb += cls_info[label] * mu_i.T @ mu_i
    r = 1e-5
    Im = np.eye(shape[1] - 1)
    A = la.pinv(Sw + r * Im) @ Sb
    eigVal, eigVec = la.eig(A)
    eigVal, eigVec = eigVal.real, eigVec.real
    eigVec = eigVec[:, np.argsort(eigVal)[-k:][::-1]]
    return eigVec


# (Sw + rI)^-1 @ Sb  --  main
def main_M5():
    # 数据处理
    face_data, fold, part = genarate_data()
    face_data, mean_face = centralize(face_data)
    face_data = addLabel(face_data, part)

    # 正式识别
    correct_rate = []
    for train_data, test_data in crossValidation(face_data, fold, discrete=True, part=part):
        train_data = np.array(sorted(train_data, key=lambda x: x[-1]))
        shape = train_data.shape
        cls_info, cls_index, cls_num = getLabelInfo(train_data)
        if shape[1] - 1 > shape[0] - cls_num:
            tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
            train_data = dotWithLabel(train_data, tr_pca)
            test_data = dotWithLabel(test_data, tr_pca)
        tr_lda = LDA_M5(train_data, cls_num - 1)
        lda_train_data = dotWithLabel(train_data, tr_lda)
        lda_test_data = dotWithLabel(test_data, tr_lda)
        test_labels = uplift(lda_test_data[:, -1])
        match_labels = KNN(lda_train_data, lda_test_data, k=1)
        correct_rate.append(sum([1 if tl == ml else 0 for tl, ml in zip(test_labels, match_labels)]) / len(test_labels))
        print('correct rate is {:.2f} %'.format(correct_rate[-1] * 100))
    print('average correct rate is {:.2f} %'.format(sum(correct_rate) / len(correct_rate) * 100))

    # 降维测试
    # shape = face_data.shape
    # cls_info, cls_index, cls_num = getLabelInfo(face_data)
    # if shape[1] - 1 > shape[0] - cls_num:
    #     tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
    #     face_data = dotWithLabel(face_data, tr_pca)
    # tr_lda = LDA_M4(face_data, cls_num - 1)
    # lda_data = dotWithLabel(face_data, tr_lda)
    # draw(dim=3)
    # for i in range(10):
    #     visualize(lda_data[i * 10: (i + 1) * 10], dim=3)
    # plt.show()
    pass


# eigenface & fisherfac
def showface(size: tuple):
    # 数据处理
    face_data, fold, part = genarate_data()
    face_data, mean_face = centralize(face_data)
    face_data = addLabel(face_data, part)
    shape = face_data.shape
    cls_info, cls_index, cls_num = getLabelInfo(face_data)
    tr_pca = PCA(face_data, shape[0] - cls_num, stripLabel=True)
    pca_face_data = dotWithLabel(face_data, tr_pca)
    tr_lda = LDA_M1(pca_face_data, cls_num - 1)
    lda_face_data = dotWithLabel(pca_face_data, tr_lda)
    # 3D 绘图
    draw(dim=3)
    resetStyle()
    for i in range(3):
        visualize(pca_face_data[i * part: (i + 1) * part], dim=3)
    plt.show()
    draw(dim=3)
    resetStyle()
    for i in range(3):
        visualize(lda_face_data[i * part: (i + 1) * part], dim=3)
    plt.show()
    # 2D 绘图
    draw(dim=2)
    resetStyle()
    for i in range(3):
        visualize(pca_face_data[i * part: (i + 1) * part], dim=2)
    plt.show()
    draw(dim=2)
    resetStyle()
    for i in range(3):
        visualize(lda_face_data[i * part: (i + 1) * part], dim=2)
    plt.show()
    # 重构人脸
    # plt.suptitle('PCA')
    # for i in range(8):
    #     face = uplift(tr_pca[:, i]).T.reshape(size)
    #     plt.subplot(2, 4, i + 1)
    #     plt.imshow(face, cmap='Greys_r')
    #     plt.axis('off')
    # plt.tight_layout()
    # plt.show()
    # plt.suptitle('LDA')
    # for i in range(8):
    #     face = (uplift(tr_lda[:, i]).T @ tr_pca.T).reshape(size)
    #     plt.subplot(2, 4, i + 1)
    #     plt.imshow(face, cmap='Greys_r')
    #     plt.axis('off')
    # plt.tight_layout()
    # plt.show()
    # 显示人脸
    # displayFacelib(face_data, 6, part, 6 * part, size=size, stripLabel=True)
    pass


if __name__ == '__main__':
    # main_M1()
    # main_M2()
    # main_M3()
    # main_M4()
    # main_M5()
    showface((46, 46))
