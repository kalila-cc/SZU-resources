import time, math
import numpy as np
import numpy.linalg as la
import scipy.io as scio
import matplotlib.pyplot as plt
from PIL import Image
from functools import wraps
from mpl_toolkits.mplot3d import Axes3D
from sklearn import datasets

datasets.clear_data_home()
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
colors = ['deepskyblue', 'limegreen', 'red', 'c', 'aqua', 'm', 'y', 'deeppink', 'darkorange', 'grey']
linestyles = ['-', '-.', '--', ':']
curColor, curLinestyle = 0, 0
ax = None


def loadMatFile(filepath: str):
    k = ''
    mat_data = scio.loadmat(filepath)
    for key in mat_data.keys():
        if not key.startswith('__'):
            k = key
            break
    return mat_data[k]


def addLabel(original_data: np.ndarray, group_num: int) -> np.ndarray:
    label = []
    for i in range(original_data.shape[0] // group_num):
        label.extend([i] * group_num)
    label = np.expand_dims(label, axis=1)
    return np.hstack((original_data, label))


def getLabelInfo(data: np.ndarray) -> (dict, list, int):
    labels = list(data[:, -1])
    info = {k: labels.count(k) for k in set(labels)}
    index = [0]
    for i in range(len(info.keys())):
        index.append(index[-1] + info[labels[index[-1]]])
    return info, index, len(info)


def centralize(original_data: np.ndarray, stripLabel: bool = False) -> (np.ndarray, np.ndarray):
    mu = np.mean(original_data, axis=0)
    mu[-1] = 0 if stripLabel else mu[-1]
    original_data -= mu
    return original_data, mu


def visualize(data: np.ndarray, dim: int, mode: str = 's'):
    global curColor, curLinestyle
    if dim == 2:
        if mode == 's':
            plt.scatter(data[:, 0], data[:, 1], color=colors[curColor])
        elif mode == 'l':
            plt.plot(data[:, 0], data[:, 1], color=colors[curColor], linestyle=linestyles[curLinestyle])
            curLinestyle += 1 if curLinestyle < 3 else -3
        curColor += 1 if curColor < 9 else -9
    elif dim == 3:
        ax.scatter(data[:, 0], data[:, 1], data[:, 2], color=colors[curColor])
        curColor += 1 if curColor < 9 else -9


def draw(dim: int):
    global ax, curColor, curLinestyle
    resetStyle()
    if dim == 2:
        ax = None
    elif dim == 3:
        ax = Axes3D(plt.figure())
        ax.set_xlabel('x axis')
        ax.set_ylabel('y axis')
        ax.set_zlabel('z axis')


def resetStyle():
    global curColor, curLinestyle
    curColor, curLinestyle = 0, 0


def dotWithLabel(data: np.ndarray, transform: np.ndarray):
    return np.hstack((data[:, :-1] @ transform, np.expand_dims(data[:, -1], axis=1)))


def PCA(original_data: np.ndarray, k: int, stripLabel: bool = False) -> np.ndarray:
    return la.svd(original_data[:, :-1].T)[0][:, :k] if stripLabel else la.svd(original_data.T)[0][:, :k]


def crossValidation(dataset: np.ndarray, fold: int, discrete: bool = False, part: int = -1) -> (np.ndarray, np.ndarray):
    if discrete:
        size, indexes = dataset.shape[0], []
        for i in range(part):
            indexes.extend(list(range(i, size + i, part)))
        dataset = dataset[indexes]
    part = dataset.shape[0] // fold
    for i in range(fold):
        train_set = np.vstack((dataset[: i * part], dataset[(i + 1) * part:]))
        test_set = dataset[i * part: (i + 1) * part]
        yield train_set, test_set


def KNN(dataset: np.ndarray, test_set: np.ndarray, k: int = 1):
    match_labels = []
    for test in test_set:
        match_set = dataset[np.argsort(la.norm((dataset - test)[:, :-1], axis=1))[:k]]
        cls_info, cls_index, cls_num = getLabelInfo(match_set)
        match_labels.append(max(cls_info, key=lambda x: cls_info[x]))
    return uplift(np.array(match_labels))


def predict(transfrom: np.ndarray, test_X: np.ndarray, test_Y: np.ndarray):
    delta = test_X @ transfrom - test_Y
    return np.squeeze(delta.T @ delta)


def uplift(vector: np.ndarray) -> np.ndarray:
    return np.expand_dims(vector, axis=1)


def getFactor(num: int):
    stop, factor = math.ceil(math.sqrt(num)), []
    for i in range(1, stop):
        if num % i == 0:
            factor.append(i)
            factor.append(num // i)
    return sorted(factor)


def selectFactor(dataset: np.ndarray, approach: int = 10):
    factor = [x - approach for x in getFactor(dataset.shape[0])]
    return factor[np.argsort(np.abs(factor))[0]] + approach


if __name__ == '__main__':
    pass
