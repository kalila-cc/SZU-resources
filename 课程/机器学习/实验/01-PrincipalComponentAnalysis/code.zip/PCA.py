import numpy as np
import numpy.linalg as la
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from utils import *

# 全局颜色
colors = ['r', 'g', 'b', 'c', 'm', 'y', 'k']
linestyles = ['-', '-.', '--', ':']


# 中心化
def centralization(original_data: np.ndarray, stripLabel: bool = False) -> tuple:
    mu = np.mean(original_data, axis=0)
    mu[-1] = 0 if stripLabel else mu[-1]
    original_data -= mu
    return original_data, mu


# 添加标签
def addLabel(original_data: np.ndarray, group_num: int) -> np.ndarray:
    label = []
    for i in range(original_data.shape[0] // group_num):
        label.extend([i] * group_num)
    label = np.expand_dims(label, axis=1)
    return np.hstack((original_data, label))


# PCA算法，此处使用了 rec 为计时装饰器，位于 utils.py
@rec(unit='ms')
def PCA(original_data: np.ndarray, k: int, stripLabel: bool = False) -> np.ndarray:
    return la.svd(original_data[:, :-1].T)[0][:, :k] if stripLabel else la.svd(original_data.T)[0][:, :k]


# 分割数据集，每个人抽取一张图作为测试集
def divideDataset(original_data: np.ndarray, group_num: int, pick: int = 1) -> tuple:
    train_indexes, test_indexes = np.array([], dtype=np.int), np.array([], dtype=np.int)
    for i in range(len(original_data) // group_num):
        index = np.arange(i * group_num, (i + 1) * group_num)
        np.random.shuffle(index)
        train_index, test_index = index[:-pick], index[-pick:]
        train_indexes = np.hstack((train_indexes, train_index))
        test_indexes = np.hstack((test_indexes, test_index))
    return original_data[train_indexes], original_data[test_indexes]


# 匹配标签，使用了 k 近邻方法分类
def matchLabel(library: np.ndarray, match_data: np.ndarray, sensitivity: int = 5):
    library, match_data, labels = library[:, :-1], match_data[:-1], library[:, -1]
    dist = np.array(list(map(lambda x: sum(np.abs(x - match_data)), library)))
    labels = list(labels[np.argsort(dist)[:sensitivity]])
    count_labels = {k: labels.count(k) for k in set(labels)}
    return max(count_labels, key=lambda x: count_labels[x])


# 人脸重构
def reconstruction(face_data: np.ndarray):
    # 防止溢出和中心化
    face_data, mu = centralization(face_data, stripLabel=False)
    face_data /= 100
    # 选择一个图进行重构比较
    face_index = np.random.randint(face_data.shape[0])
    # 分别实现 k = 20, 40, ..., 160 个投影重构
    for k in range(20, 180, 20):
        # trans 为变换矩阵
        trans = PCA(face_data, k, stripLabel=False)
        # 重构画图
        plt.subplot(4, 8, k // 20)
        plt.imshow((face_data[face_index] * 100 + mu).reshape((46, 46)), cmap='Greys_r')
        plt.axis('off')
        plt.title('original', fontdict={'size': 8})
        plt.subplot(4, 8, k // 20 + 8)
        plt.imshow((face_data[face_index] @ trans @ trans.T * 100 + mu).reshape((46, 46)), cmap='Greys_r')
        plt.axis('off')
        plt.title('k={}'.format(k), fontdict={'size': 8})
    plt.tight_layout()
    plt.show()


# 人脸识别
def recognition(face_data: np.ndarray, group_num: int):
    # 添加标签
    face_data = addLabel(face_data, group_num)
    # 针对不同训练集大小进行识别率测试
    for pick in range(1, 5):
        print('pick = {}'.format(pick))
        # 划分数据集，默认每个人的 10 张图中抽取一张作为测试集，测试集不加入训练集
        train_set, test_set = divideDataset(face_data, group_num, pick=pick)
        # 中心化训练集
        train_set, mu = centralization(train_set, stripLabel=True)
        # trans 为变换矩阵
        trans = PCA(train_set, 160, stripLabel=True)
        # 存储每次识别率数据
        recognition_rate = []
        # PCA 降维
        for k in range(10, 170, 10):
            trans_k = trans[:, :k]
            # 将训练集和测试集分别降维
            pca_train_data = np.hstack((train_set[:, :-1] @ trans_k, np.expand_dims(train_set[:, -1], axis=1)))
            pca_test_data = np.hstack(((test_set - mu)[:, :-1] @ trans_k, np.expand_dims(test_set[:, -1], axis=1)))
            # 人脸识别
            success_tiems, total_times = 0, len(pca_test_data)
            for test_item in pca_test_data:
                label = matchLabel(pca_train_data, test_item, sensitivity=5)
                success_tiems += 1 if label == test_item[-1] else 0
            print('k = {}, recognition rate = {:.2f} %'.format(k, 100 * success_tiems / total_times))
            recognition_rate.append(success_tiems / total_times)
        plt.plot(list(range(10, 170, 10)), recognition_rate, color=colors[pick % 7], linestyle=linestyles[pick % 4], label='pick={}'.format(pick))
    plt.xlabel('k')
    plt.ylabel('recognition rate')
    plt.ylim((0.75, 1.0))
    plt.title('face recognition')
    plt.legend()
    plt.show()


# 人脸在低维的可视化
def visualization(face_data: np.ndarray, group_num: int):
    # 中心化
    face_data, mu = centralization(face_data, stripLabel=False)
    # trans2D, trans3D 为变换矩阵
    trans3D = PCA(face_data, 3, stripLabel=False)
    trans2D = trans3D[:, :2]
    # 2D 可视化
    pca_face_data = face_data @ trans2D
    x, y = pca_face_data[:, 0], pca_face_data[:, 1]
    start = np.random.randint(face_data.shape[0] // group_num - 7)
    for i in range(start * group_num, (start + 7) * group_num, group_num):
        plt.scatter(x[i: i + group_num], y[i: i + group_num], color=colors[i // group_num % 7])
    plt.show()
    # 3D 可视化
    pca_face_data = face_data @ trans3D
    x, y, z = pca_face_data[:, 0], pca_face_data[:, 1], pca_face_data[:, 2]
    fig = plt.figure()
    ax = Axes3D(fig)
    for i in range(start * group_num, (start + 7) * group_num, group_num):
        ax.scatter(x[i: i + group_num], y[i: i + group_num], z[i: i + group_num], color=colors[i // group_num % 7])
    plt.show()


# 主函数，其中的 loadMatFile 位于 utils.py 用于加载 .mat 文件
def main():
    # 获取人脸库数据

    # 第一个数据集
    filepath = r'database\\ORL4646.mat'
    group_num = 10
    face_data = np.array(loadMatFile(filepath))
    shape = face_data.shape
    face_data = face_data.reshape((shape[0] * shape[1], shape[2])).T

    # 第二个数据集
    # filepath = r'database\\Yale5040165.mat'
    # group_num = 11
    # face_data = np.array(loadMatFile(filepath), dtype=np.float)
    # shape = face_data.shape
    # face_data = face_data.reshape((shape[0] * shape[1], shape[2])).T

    # 第三个数据集
    # filepath = r'database\\AR120p20s50by40.mat'
    # group_num = 20
    # face_data = np.array(loadMatFile(filepath), dtype=np.float)
    # shape = face_data.shape
    # face_data = face_data.reshape((shape[0] * shape[1], shape[2])).T[:40 * group_num]

    # 人脸重构
    reconstruction(face_data)
    # 人脸识别/
    recognition(face_data, group_num)
    # 人脸在低维的可视化
    visualization(face_data, group_num)


if __name__ == '__main__':
    main()
