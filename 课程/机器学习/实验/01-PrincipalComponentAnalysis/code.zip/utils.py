import scipy.io as scio
import time
from functools import wraps


def loadMatFile(file_path: str):
    k = ''
    mat_data = scio.loadmat(file_path)
    for key in mat_data.keys():
        if not key.startswith('__'):
            k = key
            break
    return mat_data[k]


def rec(unit: str = 'ms'):
    def _rec(f):
        @wraps(f)
        def __rec(*args, **kwargs):
            start = time.clock()
            ans = f(*args, **kwargs)
            end = time.clock()
            if unit == 'ms':
                print('Excuting function {} tooks {:.6f} ms'.format(f.__name__, (end - start) * 1000))
            elif unit == 's':
                print('Excuting function {} tooks {:.6f} s'.format(f.__name__, (end - start)))
            return ans
        return __rec
    return _rec
